<!DOCTYPE html>
<html>
  <head>
    <meta charset="utf-8">
    <title>AOS - Animate on scroll library</title>
    <meta name="viewport" content="width=device-width">
    <link rel="stylesheet" href="css/styles.css" />
    <link rel="stylesheet" href="../dist/aos.css" />
    <!--[if lt IE 9]>
    <script src="//html5shiv.googlecode.com/svn/trunk/html5.js"></script>
    <![endif]-->
  </head>
  <body>
    
      <div class="aos-itemx" data-aos="fade-right">
        
      </div>
<div style='height:800px;'></div>
      <div style='width:50%;height:200px;background:gray;margin-right:50px;' data-aos="fade-up">
        
      </div>
      
      
 
    

    <script src="../dist/aos.js"></script>
    <script>
      AOS.init({
        easing: 'ease-in-out-sine'
      });
    </script>

    <!-- <script src="//cdnjs.cloudflare.com/ajax/libs/require.js/2.1.11/require.min.js"></script>
    <script>
      requirejs.config({
          baseUrl: '../dist',
      });

      require(['aos'], function(AOS){
          AOS.init({
              easing: 'ease-in-out-sine'
          });
      });
    </script> -->
  </body>
</html>
