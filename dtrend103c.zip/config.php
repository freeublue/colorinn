<?php

$dbhost = "us-cdbr-iron-east-01.cleardb.net";
$dbname = "heroku_f18400553b651d5";
$dbuser = "bdeba2f1afd052";
$dbpass = "01e0bdf6";
  
         
         $conn = mysqli_connect($dbhost, $dbuser, $dbpass,$dbname);
   
?>
