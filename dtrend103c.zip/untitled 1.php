<?
$file = "css.txt";
$fpx = file_get_contents($file);
$new = str_replace('Minifying', '', $fpx);
$new1 = str_replace(' could save ', '', $new);
$new2 = str_replace('reduction) after compression. See optimized version.', '', $new1);
$newfile = "newcss.txt";
$fp = fopen($newfile, "a+");
fwrite($fp, $new2);
?>
 could save 577B (13% reduction) after compression. See optimized version.