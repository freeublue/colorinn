


<?
require "bootstraptop.php";
require "slide.php";
?>

<div class='container'>
<div class='row'>
<div class='col-12'>
<?
include "../../bootlib.php";
include "../../config.php";
$sqlp = mysqli_query($conn, "SELECT * FROM shipdec LIMIT");
while($row = mysqli_fetch_assoc($sqlp ) ) { 
$xd = dd . $row[id]; 
echo "$row[sh_title]<br>";
echo "$row[ad_nameid]<br>";
echo "$row[sh_type]<br>"; 
echo "$row[sh_att1]<br>";
echo "$row[sh_att1price]<br>";



echo "$row[sh_att2]<br>";
echo "$row[sh_att2price]<br>";


echo "$row[sh_att3]<br>";
echo "$row[ad_att3price]<br>";


echo "$row[ad_att4]<br>";
echo "$row[ad_att4price]<br>";



echo "$row[ad_att5]<br>";
echo "$row[ad_att5price]<br>";



echo "$row[ad_att6]<br>";
echo "$row[ad_att6price]<br>";



echo "$row[ad_att7]<br>";
echo "$row[ad_att7price]<br>";



echo "$row[ad_att8]<br>";
echo "$row[ad_att8price]<br>";



} 
?>
, ad_type, ad_att1, ad_att1price, ad_att2, ad_att2price, ad_att3, ad_att3price, ad_att4, ad_att4price, ad_att5, ad_att5price, ad_att6, ad_att6price, ad_att7, ad_att7price, ad_att8, ad_att8price, ad_att9, ad_att9price, ad_att10, ad_att10price, ad_att11, ad_att11price, ad_att12, ad_att12price










</div></div>
</div></body></html>