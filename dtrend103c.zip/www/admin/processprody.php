<?
$it_title = $_POST['it_title'];
$it_maincate = $_POST['it_maincate'];
$it_cate1 = $_POST['it_cate1'];
$it_cate2 = $_POST['it_cate2'];
$it_subtitle = $_POST['it_subtitle'];
$it_descp = $_POST['it_descp'];
$it_status  = $_POST['it_status'];

$it_quantity = $_POST['it_quality'];
$it_mainimage = $_POST['it_mainimage];
$it_mainpricd = $_POST['it_mainprice'];
$it_brand = $_POST['it_brand'];
$it_stocknumber = $_POST['it_stocknumber];
$it_substocknumber = $_POST['it_substocknumber'];
$it_SKU = $_POST['it_SKU];




$it_shipping_type1 = $_POST['it_shipping_type1'];
$it_shipping_typeid1 = $_POST['it_shipping_typeid1'];



$it_shipping_type2 = $_POST['it_shipping_type2'];
$it_shipping_typeid2 = $_POST['it_shipping_typeid2'];


$it_shipping_type3 = $_POST['it_shipping_type3'];
$it_shipping_typeid3 = $_POST['it_shipping_typeid3'];



$it_shipping_type4 = $_POST['it_shipping_type4'];
$it_shipping_typeid4 = $_POST['it_shipping_typeid4'];


$it_shipping_type5 = $_POST['it_shipping_type5'];
$it_shipping_typeid5 = $_POST['it_shipping_typeid5'];




$it_shipping_type6 = $_POST['it_shipping_type6'];
$it_shipping_typeid6 = $_POST['it_shipping_typeid6'];



$it_shipping_type7 = $_POST['it_shipping_type7'];
$it_shipping_typeid7 = $_POST['it_shipping_typeid7'];



$it_shipping_type8 = $_POST['it_shipping_type8'];
$it_shipping_typeid8 = $_POST['it_shipping_typeid8'];



$it_shipping_type9 = $_POST['it_shipping_type9'];
$it_shipping_typeid9 = $_POST['it_shipping_typeid9'];



$it_shipping_type10 = $_POST['it_shipping_type10'];
$it_shipping_typeid10 = $_POST['it_shipping_typeid10'];



$it_shipping_type11 = $_POST['it_shipping_type11];
$it_shipping_typeid11 = $_POST['it_shipping_typeid11'];



$it_shipping_type12 = $_POST['it_shipping_type12'];
$it_shipping_typeid12 = $_POST['it_shipping_typeid12'];




$it_att_type1 = $_POST['it_att_type1'];
$it_att_typeid1 = $_POST['it_att_typeid1'];


$it_att_type2 = $_POST['it_att_type2'];
$it_att_typeid2 = $_POST['it_att_typeid2'];



$it_att_type3 = $_POST['it_att_type3'];
$it_att_typeid3 = $_POST['it_att_typeid3'];


$it_att_type4 = $_POST['it_att_type4'];
$it_att_typeid4 = $_POST['it_att_typeid4'];


$it_att_type5 = $_POST['it_att_type5'];
$it_att_typeid5 = $_POST['it_att_typeid5'];




$it_downloadtype = $_POST['it_downloadtype'];
$it_downloadname = $_POST['it_downloadname'];
$it_downloadlink = $_POST['it_downloadlink'];
$it_volweight = $_POST['it_mainimage];

$it_dateadded = date("Y-m-d H:i:s");
$it_expirydate = $_POST['it_expirydate];
echo "title $it_title<br>";

?>

it_title,
it_maincate,
it_cate1,
it_cate2,
it_subtitle,
it_descp,
it_status,
it_quantity,
it_mainimage,
it_mainpricd,
it_brand,
it_stocknumber,
it_substocknumber,
it_SKU,
it_discountname1,
it_discountid1,

it_discountname2,
it_discountid2,

it_discountname3,
it_discountid3,

it_discountname4,
it_discountid4,

it_subimage1,
it_subimage2,
it_subimage3,
it_subimage4,
it_subimage5,
it_subimage6,
it_subimage7,
it_subimage8,
it_discountstatus,

it_shipping_type1,
it_shipping_typeid1,

it_shipping_type2,
it_shipping_typeid2,

it_shipping_type3,
it_shipping_typeid3,

it_shipping_type4,
it_shipping_typeid4,

it_shipping_type5,
it_shipping_typeid5,

it_shipping_type6,
it_shipping_typeid6,

it_shipping_type7,
it_shipping_typeid7,

it_shipping_type8,
it_shipping_typeid8,

it_shipping_type9,
it_shipping_typeid9,

it_shipping_type10,
it_shipping_typeid10,

it_shipping_type11,
it_shipping_typeid11,

it_shipping_type12,
it_shipping_typeid12,







it_att_type1,
it_att_typeid1,

it_att_type2,
it_att_typeid2,

it_att_type3,
it_att_typeid3,

it_att_type4,
it_att_typeid4,

it_att_type5,
it_att_typeid5,

it_att_type6,
it_att_typeid6,

it_att_type7,
it_att_typeid7,

it_att_type8,
it_att_typeid8,

it_att_type9,
it_att_typeid9,

it_att_type10,
it_att_typeid10,

it_att_type11,
it_att_typeid11,

it_att_type12,
it_att_typeid12,









it_downloadtype,
it_downloadname,
it_downloadlink,
it_volweight,

it_dateadded,
it_expirydate