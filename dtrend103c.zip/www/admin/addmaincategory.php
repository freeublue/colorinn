<?
require "bootstraptop.php";
require "slide.php";
?>
<style>
#results{ 
display:none;

} 
#myid { 
display:none;
} 
</style>
<script>
function validateForm()
{
var x=document.forms["myform"]["addtype"].value;
if (x==null || x=="")
  {
  alert("Title must be filled out");
  return false;
  } 



   



}
</script>
<div class='container'>
<div class='row'>
<div class='col-6'>
<?
include "../../lib.php";
include "../../config.php";

echo "<form name='myform'>";
echo "<h4>Enter Type</h4><p>Types serve as categories. Each group may be inserted into a matching categories. </p><br />";

           echo "<input id='addtype' name='addtype' type='text'> 
               
                  <button id='add_em' class='btn btn-primary' type='button'> 
                     Go! 
                  </button></form<p><div id='results'>gg</div></p>"; 


?>
</div>
<div class='col-6'>

<?php
echo "<h4>Edit Type</h4><p>Types serve as categories. Each group may be inserted into a matching categories. </p><br />";
$sqlp = mysqli_query($conn, "SELECT * FROM mainprodcate LIMIT 0, 30 ");
while($row = mysqli_fetch_assoc($sqlp ) ) { 
$xd = dd . $row[id];
echo "<span><a href='editmaincate.php?ty=$row[id]'><i class='far fa-edit'></i> $row[mcate_title] </a></span>|<i id='$row[id]' onclick='showurl(this.id);' class='fa fa-trash' aria-hidden='true'></i><br /><br><br>"; } 
echo "<a style='height:100px;background:black;color:white;width:150px;text-align:center;padding:10px;' id='myid' href=''> Are you Sure you want to delete<br>Delete</a></div>";
?>

</div>
</div>











</div>
<div class='col-6'>



</div>
</div>


<script src="https://ajax.googleapis.com/ajax/libs/jquery/1.8.0/jquery.min.js" type="text/javascript"></script>
<script>
$(document).ready(function(){ 

$("#results").slideUp(); 

    $("#add_em").click(function(e){ 
        e.preventDefault(); 

        ajax_sear(); 
    }); 
     




}); 


function ajax_sear(){ 

  $("#results").show(); 
  
var typename = $("#addtype").val();


  $.post("processmaincate.php", {type : typename }, function(data){
   if (data.length>0){ 

   $("#results").html(data); 
   } 
  }) 
} 




</script>
<script>
var sid;
function showurl(sid) { 
var f = "dd" + sid;
document.getElementById("myid").style.display = "block";
document.getElementById("myid").href = "deletemaincate.php?ty="+sid;

} 

</script>


