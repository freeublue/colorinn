<?
require "bootstraptop.php";
require "slide.php";
?>

<div class='container'>
<div class='row'>
<div class='col-12'>
<script>
function validateForm()
{
var x=document.forms["rform"]["addtype"].value;
if (x==null || x=="")
  {
  alert("Title must be filled out");
  return false;
  } 


var xc=document.forms["rform"]["subhead"].value;
if (xc==null || xc=="")
  {
  alert("phrase must be filled out");
  return false;
  } 
  var xc1=document.forms["rform"]["descp"].value;
if (xc1==null || xc1=="")
  {
  alert("Text must be filled out");
  return false;
  } 
   



}
</script>
<?
include "../../lib.php";
include "../../config.php";

           echo "<form name='rform' action='processabout.php' onsubmit='return validateForm();' method='post'><label>Title Header</label><br><input id='addtype' name='addtype' /><label>Sub Header</label><br><input id='subhead' name='subhead' /><br>
           <label>Add Image</label><input id='img' name='img' type='text'><br>
           <label>Short Description</label><br>
           <textarea rows='25' cols='50' name='descp'></textarea><br>
                      <label>Add Date</label><input id='day' name='day' type='date'><br>";
                      
   

                  echo "<button id='add_em' class='btn btn-danger' type='submit'> 
                     Go! 
                  </button>";
echo "</form>";
?>
</div></div>
<div class='row'>
<div class='col-12'>
<?
//$sq = $("SELECT * FROM about");
//while()) { 
//echo "<a href='editabout.php?id=$row[ab_id]'><i class='far fa-edit'></i>
//$row[ab_title]</a><br>";
//} 
//?>
</div></div>
</div></body></html>

