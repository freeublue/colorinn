<!DOCTYPE html>
<html>
<head>
<style>
body {
    font-family: "Lato", sans-serif;
}

.sidenav {
    height: 100%;
    width: 0;
    position: fixed;
    z-index: 1;
    top: 0;
    left: 0;
    background-color: #111;
    overflow-x: hidden;
    transition: 0.5s;
    padding-top: 60px;
}

.sidenav a {
    padding: 8px 8px 8px 32px;
    text-decoration: none;
    font-size: 25px;
    color: #818181;
    display: block;
    transition: 0.3s;
}

.sidenav a:hover, .offcanvas a:focus{
    color: #f1f1f1;
}

.sidenav .closebtn {
    position: absolute;
    top: 50;
    right: 25px;
    font-size: 26px;
    margin-left: 50px;
}

@media screen and (max-height: 750px) {
  .sidenav {padding-top: 15px;}
  .sidenav a {font-size: 18px;}
}
</style>


<div id="mySidenav" class="sidenav">
  <a href="javascript:void(0)" class="closebtn" onclick="closeNav()">&times;</a>
  <a href="index.php">Home</a>
  <a href="addbusiness.php">Manage Business Details</a>
  <a href="addmaincategory.php">Manage Main Category</a>
  <a href="addlocation.php">Manage Locations</a>
  <a href="addcategory.php">Manage Category/Brand/Payment</a>
<a href="addsubcate.php">Manage Subcategories</a>

<a href="selectnewsletter.php">Manage Newsletter</a>
<a href="generategeo.php">Generate Maplisting</a>
<a href="editpages.php">Manage Pages</a>
<a href="getcords.php">Get Co-ordinates Latitude </a>
<a href="addmentor.php">Add Staff Account </a>

<a href='documentation/index.php'>Documentation</a>
?>

</div>

<span style="font-size:30px;cursor:pointer" onclick="openNav()">&#9776; </span>

<script>
function openNav() {
    document.getElementById("mySidenav").style.width = "250px";
}

function closeNav() {
    document.getElementById("mySidenav").style.width = "0";
}
</script>
     