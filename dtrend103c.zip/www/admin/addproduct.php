<?
require "slide.php";
?>
<style>
#results{ 
display:none;

} 
#myid { 
display:none;
} 
</style>
<div class='container'>
<div class='row'>
<div class='col-12'>
<?
include "../functions/bootlib.php";
include "../../config.php";
echo "<div class='container'>
<div class='row'>";
echo "<div class='col-6'>";
$maincate = $_REQUEST['id'];
$sqlp = mysqli_query($conn, "SELECT * FROM mainprodcate WHERE id = '$maincate'");
while($row = mysqli_fetch_assoc($sqlp ) ) { 
$maincategory = $row[mcate_title];
} 
echo "<form enctype='multipart/form-data' action='processprod.php' method='post'>";
echo "<input type='text' value='$maincategory' name='it_maincate' /><br>";
echo "<label>SubCategory</label><br>";
echo "<select name='it_cate1'>";
$sqlp = mysqli_query($conn, "SELECT * FROM prodcate1 WHERE pcate_maincateid = '$maincate'");
while($row = mysqli_fetch_assoc($sqlp ) ) { 
echo "<option value='$row[pcate_title]'>$row[pcate_title]</option>"; 
} 
echo "</select><br>";
echo "<label>SubCategory</label><br>";
echo "<select name='it_cate2'>";
$sqlp = mysqli_query($conn, "SELECT * FROM prodcate1 WHERE pcate_maincateid = '$maincate'");
while($row = mysqli_fetch_assoc($sqlp ) ) { 
echo "<option value='$row[pcate_title]'>$row[pcate_title]</option>"; 
} 
echo "</select><br>";

echo "<label>Product Title</label>";
echo "<input type='text' name='it_title' /><br>";

echo "<label>Product SubTitle</label>";
echo "<input type='text' name='it_subtitle' /><br>";

echo "<label>Shipping Description</label>";
echo "<textarea rows='20' cols='20' name='it_descp' ></textarea><br>";

echo "<label>Product status </label><br>
      <select name='it_status'>
      <option value='Active'>Active </option>
      <option value='InActive'>InActive</option>
      </select><br>";

echo "<label>Product Quantity</label>";
echo "<input type='text' name='it_quantity' /><br>";



echo "<label>Product Main Price</label>";
echo "<input type='text' name='it_mainpricd' /><br>";
//remember to make a brand table with logo facilities
echo "<label>Product Brand</label>";
echo "<input type='text' name='it_brand' /><br>";
echo "<label>Stock Number</label>";
echo "<input type='text' name='it_stocknumber' /><br>";





echo "<label>Product Substock Number </label>";
echo "<input type='text' name='it_substocknumber' /><br>";
echo "<label>Product SKU</label>";
echo "<input type='text' name='it_SKU' /><br>";

echo "<label>Add attribute 1</label><br>";
echo "<select name='it_att_type1'>";
echo "<option value=' '>None</option>";
$sqlp = mysqli_query($conn, "SELECT * FROM attdec");
while($row = mysqli_fetch_assoc($sqlp ) ) { 
$xd = $row[ad_title] . "|" . $row[id];

echo "<option value='$xd'>$row[ad_title]</option>"; } 
echo "</select><br>"; 


echo "<label>Add attribute 2</label><br>";
echo "<select name='it_att_type2'>";
echo "<option value=' '>None</option>";
$sqlp = mysqli_query($conn, "SELECT * FROM attdec");
while($row = mysqli_fetch_assoc($sqlp ) ) { 
$xd = $row[ad_title] . "|" . $row[id];

echo "<option value='$xd'>$row[ad_title]</option>"; } 
echo "</select><br>"; 



echo "<label>Add attribute 3</label><br>";
echo "<select name='it_att_type3'>";
echo "<option value=' '>None</option>";
$sqlp = mysqli_query($conn, "SELECT * FROM attdec");
while($row = mysqli_fetch_assoc($sqlp ) ) { 
$xd = $row[ad_title] . "|" . $row[id];

echo "<option value='$xd'>$row[ad_title]</option>"; } 
echo "</select><br>"; 




echo "<label>Add attribute 4</label><br>";
echo "<select name='it_att_type4'>";
echo "<option value=' '>None</option>";
$sqlp = mysqli_query($conn, "SELECT * FROM attdec");
while($row = mysqli_fetch_assoc($sqlp ) ) { 
$xd = $row[ad_title] . "|" . $row[id];

echo "<option value='$xd'>$row[ad_title]</option>"; } 
echo "</select><br>"; 


echo "<label>Add attribute 5</label><br>";
echo "<select name='it_att_type5'>";
echo "<option value=' '>None</option>";
$sqlp = mysqli_query($conn, "SELECT * FROM attdec");
while($row = mysqli_fetch_assoc($sqlp ) ) { 
$xd = $row[ad_title] . "|" . $row[id];

echo "<option value='$xd'>$row[ad_title]</option>"; } 
echo "</select><br>"; 





echo "<label>Add attribute 6</label><br>";
echo "<select name='it_att_type6'>";
echo "<option value=' '>None</option>";
$sqlp = mysqli_query($conn, "SELECT * FROM attdec");
while($row = mysqli_fetch_assoc($sqlp ) ) { 
$xd = $row[ad_title] . "|" . $row[id];

echo "<option value='$xd'>$row[ad_title]</option>"; } 
echo "</select><br>"; 



echo "<label>Add attribute 7</label><br>";
echo "<select name='it_att_type7'>";
echo "<option value=' '>None</option>";
$sqlp = mysqli_query($conn, "SELECT * FROM attdec");
while($row = mysqli_fetch_assoc($sqlp ) ) { 
$xd = $row[ad_title] . "|" . $row[id];

echo "<option value='$xd'>$row[ad_title]</option>"; } 
echo "</select><br>"; 



echo "<label>Add attribute 8</label><br>";
echo "<select name='it_att_type8'>";
echo "<option value=' '>None</option>";
$sqlp = mysqli_query($conn, "SELECT * FROM attdec");
while($row = mysqli_fetch_assoc($sqlp ) ) { 
$xd = $row[ad_title] . "|" . $row[id];

echo "<option value='$xd'>$row[ad_title]</option>"; } 
echo "</select><br>"; 




echo "<label>Add attribute 9</label><br>";
echo "<select name='it_att_type9'>";
echo "<option value=' '>None</option>";
$sqlp = mysqli_query($conn, "SELECT * FROM attdec");
while($row = mysqli_fetch_assoc($sqlp ) ) { 
$xd = $row[ad_title] . "|" . $row[id];

echo "<option value='$xd'>$row[ad_title]</option>"; } 
echo "</select><br>"; 


echo "<label>Add attribute 10</label><br>";
echo "<select name='it_att_type10'>";
echo "<option value=' '>None</option>";
$sqlp = mysqli_query($conn, "SELECT * FROM attdec");
while($row = mysqli_fetch_assoc($sqlp ) ) { 
$xd = $row[ad_title] . "|" . $row[id];

echo "<option value='$xd'>$row[ad_title]</option>"; } 
echo "</select><br>"; 




echo "<label>Add attribute 11</label><br>";
echo "<select name='it_att_type11'>";
echo "<option value=' '>None</option>";
$sqlp = mysqli_query($conn, "SELECT * FROM attdec");
while($row = mysqli_fetch_assoc($sqlp ) ) { 
$xd = $row[ad_title] . "|" . $row[id];

echo "<option value='$xd'>$row[ad_title]</option>"; } 
echo "</select><br>"; 




echo "<label>Add attribute 12</label><br>";
echo "<select name='it_att_type12'>";
echo "<option value=' '>None</option>";
$sqlp = mysqli_query($conn, "SELECT * FROM attdec");
while($row = mysqli_fetch_assoc($sqlp ) ) { 
$xd = $row[ad_title] . "|" . $row[id];

echo "<option value='$xd'>$row[ad_title]</option>"; } 
echo "</select><br>"; 


echo "<label>Shipping type 1</label><br>";
echo "<select name='it_shipping_type1'>";
echo "<option value=' '>None</option>";
$sqlp = mysqli_query($conn, "SELECT * FROM shipdec");
while($row = mysqli_fetch_assoc($sqlp ) ) { 
$xd = $row[sh_title] . "|" . $row[id];

echo "<option value='$xd'>$row[sh_title] $row[sh_subtitle]</option>"; } 
echo "</select><br>"; 




echo "<label>Shipping type 2</label><br>";
echo "<select name='it_shipping_type2'>";
echo "<option value=' '>None</option>";
$sqlp = mysqli_query($conn, "SELECT * FROM shipdec");
while($row = mysqli_fetch_assoc($sqlp ) ) { 
$xd = $row[sh_title] . "|" . $row[id];

echo "<option value='$xd'>$row[sh_title] $row[sh_subtitle]</option>"; } 
echo "</select><br>"; 




echo "<label>Shipping type 3</label><br>";
echo "<select name='it_shipping_type3'>";
echo "<option value=' '>None</option>";
$sqlp = mysqli_query($conn, "SELECT * FROM shipdec");
while($row = mysqli_fetch_assoc($sqlp ) ) { 
$xd = $row[sh_title] . "|" . $row[id];

echo "<option value='$xd'>$row[sh_title] $row[sh_subtitle]</option>"; } 
echo "</select><br>"; 






echo "<label>Shipping type 4</label><br>";
echo "<select name='it_shipping_type4'>";
echo "<option value=' '>None</option>";
$sqlp = mysqli_query($conn, "SELECT * FROM shipdec");
while($row = mysqli_fetch_assoc($sqlp ) ) { 
$xd = $row[sh_title] . "|" . $row[id];

echo "<option value='$xd'>$row[sh_title] $row[sh_subtitle]</option>"; } 
echo "</select><br>"; 







echo "<label>Shipping type 5</label><br>";
echo "<select name='it_shipping_type5'>";
echo "<option value=' '>None</option>";
$sqlp = mysqli_query($conn, "SELECT * FROM shipdec");
while($row = mysqli_fetch_assoc($sqlp ) ) { 
$xd = $row[sh_title] . "|" . $row[id];

echo "<option value='$xd'>$row[sh_title] $row[sh_subtitle]</option>"; } 
echo "</select><br>"; 







echo "<label>Shipping type 6</label><br>";
echo "<select name='it_shipping_type6'>";
echo "<option value=' '>None</option>";
$sqlp = mysqli_query($conn, "SELECT * FROM shipdec");
while($row = mysqli_fetch_assoc($sqlp ) ) { 
$xd = $row[sh_title] . "|" . $row[id];

echo "<option value='$xd'>$row[sh_title] $row[sh_subtitle]</option>"; } 
echo "</select><br>"; 


echo "<label>Shipping type 7</label><br>";
echo "<select name='it_shipping_type7'>";
echo "<option value=' '>None</option>";
$sqlp = mysqli_query($conn, "SELECT * FROM shipdec");
while($row = mysqli_fetch_assoc($sqlp ) ) { 
$xd = $row[sh_title] . "|" . $row[id];

echo "<option value='$xd'>$row[sh_title] $row[sh_subtitle]</option>"; } 
echo "</select><br>"; 




echo "<label>Shipping type 8</label><br>";
echo "<select name='it_shipping_type8'>";
echo "<option value=' '>None</option>";
$sqlp = mysqli_query($conn, "SELECT * FROM shipdec");
while($row = mysqli_fetch_assoc($sqlp ) ) { 
$xd = $row[sh_title] . "|" . $row[id];

echo "<option value='$xd'>$row[sh_title] $row[sh_subtitle]</option>"; } 
echo "</select><br>"; 



echo "<label>Shipping type 9</label><br>";
echo "<select name='it_shipping_type9'>";
echo "<option value=' '>None</option>";
$sqlp = mysqli_query($conn, "SELECT * FROM shipdec");
while($row = mysqli_fetch_assoc($sqlp ) ) { 
$xd = $row[sh_title] . "|" . $row[id];

echo "<option value='$xd'>$row[sh_title] $row[sh_subtitle]</option>"; } 
echo "</select><br>"; 






echo "<label>Shipping type 10</label><br>";
echo "<select name='it_shipping_type10'>";
echo "<option value=' '>None</option>";
$sqlp = mysqli_query($conn, "SELECT * FROM shipdec");
while($row = mysqli_fetch_assoc($sqlp ) ) { 
$xd = $row[sh_title] . "|" . $row[id];

echo "<option value='$xd'>$row[sh_title] $row[sh_subtitle]</option>"; } 
echo "</select><br>"; 



echo "<label>Shipping type 11</label><br>";
echo "<select name='it_shipping_type11'>";
echo "<option value=' '>None</option>";
$sqlp = mysqli_query($conn, "SELECT * FROM shipdec");
while($row = mysqli_fetch_assoc($sqlp ) ) { 
$xd = $row[sh_title] . "|" . $row[id];

echo "<option value='$xd'>$row[sh_title] $row[sh_subtitle]</option>"; } 
echo "</select><br>"; 





echo "<label>Shipping type 12</label><br>";
echo "<select name='it_shipping_type12'>";
echo "<option value=' '>None</option>";
$sqlp = mysqli_query($conn, "SELECT * FROM shipdec");
while($row = mysqli_fetch_assoc($sqlp ) ) { 
$xd = $row[sh_title] . "|" . $row[id];

echo "<option value='$xd'>$row[sh_title] $row[sh_subtitle]</option>"; } 
echo "</select><br>"; 

echo "<label>Sales Tax Type </label><br>
      <select name='it_sttype'>
      <option value='inclusive'>Inclusive </option>
      <option value='exclusive'>Exclusive</option>
      <option value='exempt'>Exempt</option>
      </select><br>";


echo "<label>Sales Tax Rate</label>";
echo "<input type='text' name='it_strate' /><br>";


echo "<label>Download or Ship </label><br>
      <select name='it_downloadtype'>
      <option value='real'>Real</option>
      <option value='digital'>Digital</option>
      </select><br>";


echo "<label>Download Name</label>";
echo "<input type='text' name='it_downloadname' /><br>";

echo "<label>Download Link</label>";
echo "<input type='text' name='it_downloadlink' /><br>";
echo "<label>Volumetric Weigth</label>";
echo "<input type='text' name='it_volweight' /><br>";








echo "<input type='submit' name='submit' value='submit' /></form>";

echo "</div>
<div class='col-6'>";
echo "<h4>Edit Shipping Descriptions</h4><p></p><br />";
$sqlp = mysqli_query($conn, "SELECT * FROM proditem1");
while($row = mysqli_fetch_assoc($sqlp ) ) { 
$xd = dd . $row[id];
echo "<span><a href='editshipdec.php?ty=$row[id]'><i class='far fa-edit'></i> $row[sh_subtitle] </a></span>|<i id='$row[id]' onclick='showurl(this.id);' class='fa fa-trash' aria-hidden='true'></i><br /><br><br>"; } 
echo "<a style='height:100px;background:black;color:white;width:150px;text-align:center;padding:10px;' id='myid' href=''> Are you Sure you want to delete<br>Delete</a></div>";

?>
</div>
</div></body></html>

   
<script>
var sid;
function showurl(sid) { 
var f = "dd" + sid;
document.getElementById("myid").style.display = "block";
document.getElementById("myid").href = "deleteshipdec.php?ty="+sid;

} 

</script>

 proditem1(id INT 
NOT NULL
AUTO_INCREMENT,
PRIMARY KEY(id),
it_title VARCHAR(255),
it_maincate VARCHAR(255),
it_cate1 VARCHAR(255),
it_cate2 VARCHAR(255), 
it_subtitle VARCHAR(255),
it_descp VARCHAR(255),
it_status VARCHAR(255),
it_quantity VARCHAR(255),
it_mainimage VARCHAR(255),
it_mainpricd VARCHAR(255),
it_brand VARCHAR(255),
it_stocknumber VARCHAR(255),
it_substocknumber VARCHAR(255),
it_SKU VARCHAR(255), 
it_discountname1 VARCHAR(255),
it_discountid1 VARCHAR(255),

it_discountname2 VARCHAR(255),
it_discountid2 VARCHAR(255),

it_discountname3 VARCHAR(255),
it_discountid3 VARCHAR(255),

it_discountname4 VARCHAR(255),
it_discountid4 VARCHAR(255),

it_subimage1 VARCHAR(255),
it_subimage2 VARCHAR(255),
it_subimage3 VARCHAR(255),
it_subimage4 VARCHAR(255),
it_subimage5 VARCHAR(255),
it_subimage6 VARCHAR(255),
it_subimage7 VARCHAR(255),
it_subimage8 VARCHAR(255),
it_discountstatus VARCHAR(255),

it_shipping_type1 VARCHAR(255),
it_shipping_typeid1 VARCHAR(255),

it_shipping_type2 VARCHAR(255),
it_shipping_typeid2 VARCHAR(255),

it_shipping_type3 VARCHAR(255),
it_shipping_typeid3 VARCHAR(255),

it_shipping_type4 VARCHAR(255),
it_shipping_typeid4 VARCHAR(255), 

it_shipping_type5 VARCHAR(255),
it_shipping_typeid5 VARCHAR(255),

it_shipping_type6 VARCHAR(255),
it_shipping_typeid6 VARCHAR(255),

it_shipping_type7 VARCHAR(255),
it_shipping_typeid7 VARCHAR(255),

it_shipping_type8 VARCHAR(255),
it_shipping_typeid8 VARCHAR(255),

it_shipping_type9 VARCHAR(255),
it_shipping_typeid9 VARCHAR(255),

it_shipping_type10 VARCHAR(255),
it_shipping_typeid10 VARCHAR(255),

it_shipping_type11 VARCHAR(255),
it_shipping_typeid11 VARCHAR(255),

it_shipping_type12 VARCHAR(255),
it_shipping_typeid12 VARCHAR(255),







it_att_type1 VARCHAR(255),
it_att_typeid1 VARCHAR(255),

it_att_type2 VARCHAR(255),
it_att_typeid2 VARCHAR(255),

it_att_type3 VARCHAR(255),
it_att_typeid3 VARCHAR(255),

it_att_type4 VARCHAR(255),
it_att_typeid4 VARCHAR(255), 

it_att_type5 VARCHAR(255),
it_att_typeid5 VARCHAR(255),

it_att_type6 VARCHAR(255),
it_att_typeid6 VARCHAR(255),

it_att_type7 VARCHAR(255),
it_att_typeid7 VARCHAR(255),

it_att_type8 VARCHAR(255),
it_att_typeid8 VARCHAR(255),

it_att_type9 VARCHAR(255),
it_att_typeid9 VARCHAR(255),

it_att_type10 VARCHAR(255),
it_att_typeid10 VARCHAR(255),

it_att_type11 VARCHAR(255),
it_att_typeid11 VARCHAR(255),

it_att_type12 VARCHAR(255),
it_att_typeid12 VARCHAR(255),









it_downloadtype VARCHAR(255),
it_downloadname VARCHAR(255),
it_downloadlink VARCHAR(255), 
it_volweight VARCHAR(255), 

it_dateadded DATE DEFAULT '0000-00-00',
it_expirydate DATE DEFAULT '0000-00-00'
)";







  




