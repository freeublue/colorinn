<?
include "../../config.php";
$ad_titlex = $_POST['ad_title'];
$adarray = explode('|', $ad_titlex);
$ad_title = $adarray[0];
$ad_nameid = $adarray[1];
$ad_type = $_POST['ad_type'];
$ad_att1 = $_POST['ad_att1'];
$ad_att1price = $_POST['ad_att1price'];
$ad_att2 = $_POST['ad_att2'];
$ad_att2price = $_POST['ad_att2price'];
$ad_att3 = $_POST['ad_att3'];
$ad_att3price = $_POST['ad_att3price'];
$ad_att4 = $_POST['ad_att4'];
$ad_att4price = $_POST['ad_att4price'];
$ad_att5 = $_POST['ad_att5'];
$ad_att5price = $_POST['ad_att5price'];
$ad_att6 = $_POST['ad_att6'];
$ad_att6price = $_POST['ad_att6price'];
$ad_att7 = $_POST['ad_att7'];
$ad_att7price = $_POST['ad_att7price'];
$ad_att8 = $_POST['ad_att8'];
$ad_att8price = $_POST['ad_att8price'];
$ad_att9 = $_POST['ad_att9'];
$ad_att9price = $_POST['ad_att9price'];
$ad_att10 = $_POST['ad_att10'];
$ad_att10price = $_POST['ad_att10price'];
$ad_att11 = $_POST['ad_att11'];
$ad_att11price = $_POST['ad_att11price'];
$ad_att12 = $_POST['ad_att12'];
$ad_att12price = $_POST['ad_att12price'];
echo "Success added to data<br>"; 
$sq = ("INSERT INTO attdec(ad_title, ad_nameid, ad_type, ad_att1, ad_att1price, ad_att2, ad_att2price, ad_att3, ad_att3price, ad_att4, ad_att4price, ad_att5, ad_att5price, ad_att6, ad_att6price, ad_att7, ad_att7price, ad_att8, ad_att8price, ad_att9, ad_att9price, ad_att10, ad_att10price, ad_att11, ad_att11price, ad_att12, ad_att12price) values('$ad_title', '$ad_nameid', '$ad_type', '$ad_att1', '$ad_att1price', '$ad_att2', '$ad_att2price', '$ad_att3', '$ad_att3price', '$ad_att4', '$ad_att4price', '$ad_att5', '$ad_att5price', '$ad_att6', '$ad_att6price', '$ad_att7', '$ad_att7price', '$ad_att8', '$ad_att8price', '$ad_att9', '$ad_att9price', '$ad_att10', '$ad_att10price', '$ad_att11', '$ad_att11price', '$ad_att12', '$ad_att12price')");       
if (mysqli_query($conn, $sq))
  {
  echo "Table $tablename created successfully";
  }
else
  {
  echo "Error creating table: " . mysqli_error($conn);
  }
?>

