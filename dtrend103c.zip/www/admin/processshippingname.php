
<?
include "../../config.php";
$ptype = $_POST['type'];
echo "$ptype added to data<br>"; 
$sq = ("INSERT INTO shipname(shn_title) values('$ptype')");       
$res = mysqli_query($conn, $sq);
?>
