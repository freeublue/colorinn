


<?
require "bootstraptop.php";
require "slide.php";
?>

<div class='container'>
<div class='row'>
<div class='col-12'>
<?
include "../../bootlib.php";
include "../../config.php";
$sqlp = mysqli_query($conn, "SELECT * FROM mainprodcate");
while($row = mysqli_fetch_assoc($sqlp ) ) { 
$xd = dd . $row[id]; 

echo "<a href='addproduct.php?id=$row[id]'>$row[mcate_title]</a><br>"; 




} 
?>











</div></div>
</div></body></html>