<?
include "../../config.php";
$ad_titlex = $_POST['sh_title'];
$adarray = explode('|', $ad_titlex);
$sh_title = $adarray[0];
$sh_nameid = $adarray[1];
$sh_type = $_POST['sh_type'];
$sh_descp = mysqli_real_escape_string($conn, $_POST['sh_descp']);
$sh_subtitle = mysqli_real_escape_string($conn, $_POST['sh_subtitle']);
$sh_att1 = $_POST['sh_att1'];
$sh_att1price = $_POST['sh_att1price'];
$sh_att2 = $_POST['sh_att2'];
$sh_att2price = $_POST['sh_att2price'];
$sh_att3 = $_POST['sh_att3'];
$sh_att3price = $_POST['sh_att3price'];
$sh_att4 = $_POST['sh_att4'];
$sh_att4price = $_POST['sh_att4price'];
$sh_att5 = $_POST['sh_att5'];
$sh_att5price = $_POST['sh_att5price'];
$sh_att6 = $_POST['sh_att6'];
$sh_att6price = $_POST['sh_att6price'];
$sh_att7 = $_POST['sh_att7'];
$sh_att7price = $_POST['sh_att7price'];
$sh_att8 = $_POST['sh_att8'];
$sh_att8price = $_POST['sh_att8price'];
$sh_att9 = $_POST['sh_att9'];
$sh_att9price = $_POST['sh_att9price'];
$sh_att10 = $_POST['sh_att10'];
$sh_att10price = $_POST['sh_att10price'];
$sh_att11 = $_POST['sh_att11'];
$sh_att11price = $_POST['sh_att11price'];
$sh_att12 = $_POST['sh_att12'];
$sh_att12price = $_POST['sh_att12price'];
echo "Success added to data<br>"; 
$sq = ("INSERT INTO shipdec(sh_title, sh_subtitle, sh_descp, sh_type, sh_att1, sh_att1price, sh_att2, sh_att2price, sh_att3, sh_att3price, sh_att4, sh_att4price, sh_att5, sh_att5price, sh_att6, sh_att6price, sh_att7, sh_att7price, sh_att8, sh_att8price, sh_att9, sh_att9price, sh_att10, sh_att10price, sh_att11, sh_att11price, sh_att12, sh_att12price) values('$sh_title', '$sh_subtitle', '$sh_descp', '$sh_type', '$sh_att1', '$sh_att1price', '$sh_att2', '$sh_att2price', '$sh_att3', '$sh_att3price', '$sh_att4', '$sh_att4price', '$sh_att5', '$sh_att5price', '$sh_att6', '$sh_att6price', '$sh_att7', '$sh_att7price', '$sh_att8', '$sh_att8price', '$sh_att9', '$sh_att9price', '$sh_att10', '$sh_att10price', '$sh_att11', '$sh_att11price', '$sh_att12', '$sh_att12price')");       
if (mysqli_query($conn, $sq))
  {
  echo "Table $tablename created successfully";
  }
else
  {
  echo "Error creating table: " . mysqli_error($conn);
  }
?>


