<!doctype html>
<html lang="en">
  <head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
    <meta name="description" content="">
    <meta name="author" content="">
    <link rel="icon" href="../../../../favicon.ico"><link href="https://fonts.googleapis.com/css?family=Merriweather:400,900i" rel="stylesheet"><link href="https://cdn.datatables.net/1.10.19/css/jquery.dataTables.min.css" rel="stylesheet"><script src="https://code.jquery.com/jquery-3.3.1.js"></script><script src="https://cdn.datatables.net/1.10.19/js/jquery.dataTables.min.js"></script>

    <title>ColorInn</title>

    <!-- Bootstrap core CSS -->

    <!-- Bootstrap core CSS --><link href="https://stackpath.bootstrapcdn.com/bootstrap/4.1.3/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-MCw98/SFnGE8fJT3GXwEOngsV7Zt27NXFoaoApmYm81iuXoPkFOJwJ8ERdknLPMO" crossorigin="anonymous"><link href="css/style.css" rel="stylesheet"><link href="animate.css" rel="stylesheet"><link rel="stylesheet" href="https://use.fontawesome.com/releases/v5.3.1/css/all.css" integrity="sha384-mzrmE5qonljUremFsqc01SB46JvROS7bZs3IO2EmfFsd15uHvIt+Y8vEf7N7fWAU" crossorigin="anonymous"><style>
/* Padding below the footer and lighter body text */




html, body { overflow-x: hidden; }
body {
 width:100%;
  color: black;
  font-family: "Raleway", Arial, Helvetica, sans-serif;
}
#footer {
    position: fixed;
    left: 0;
    bottom: 0;
    width: 100%;
    background-color: black;
    color: white;
    text-align: center;
  overflow-x: hidden;  
  
}
.container{ 
overflow-x: hidden;
width:100%;
} 
.carousel-inner > .item > img{
margin:auto;
}

.carousel-inner > .item > img{
margin:auto;
width:100%;
}

h2{ 
font-family: 'Dancing Script', cursive;
} 
h4 {font-family: 'Merriweather', serif;}
#headimage { 
 background: url(met1.jpg) no-repeat center center; 
 height:800px;
   background-size: cover; 
   
   

color:white;
width:100%;} 
#headstart { 
 background: url(pep3.jpg) no-repeat center center; 
 height:800px;
   background-size: cover; 
   
   

color:#d9534f;
width:100%;} 
#im1 { 
 background: url(met4.jpg) no-repeat center center; 
   background-size: cover; 
   height: 100%; 
   width: 100%;
padding:10px;
color:white;
width:100%;} 
#im2 { 
 background: url(met2.jpg) no-repeat center center; 
   background-size: cover; 
   height: 100%; 
   width: 100%;
padding:10px;
color:white;
width:100%;} 
#im3 { 
 background: url(met1.jpg) no-repeat center center; 
   background-size: cover; 
   height: 100%; 
   width: 100%;
padding:10px;
color:white;
width:100%;} 
input { 

width:100%;
 } 
.icon-bar {
  position: fixed;
  top: 40%;
  z-index:5;
  -webkit-transform: translateY(-50%);
  -ms-transform: translateY(-50%);
  transform: translateY(-50%);
}

/* Style the icon bar links */
.icon-bar a {
  display: block;
  text-align: center;
  padding: 16px;
  transition: all 0.3s ease;
  color: white;
  font-size: 20px;
}

/* Style the social media icons with color, if you want */
.icon-bar a:hover {
  background-color: #000;
}

.cartadd {
  position: fixed;
  top: 50%;
  z-index:5;
  -webkit-transform: translateY(-50%);
  -ms-transform: translateY(-50%);
  transform: translateY(-50%);
  background:black;
  color:white;
  padding:15px;
}

/* Style the icon bar links */
.cartadd a {
  display: block;
  text-align: center;
  padding: 16px;
  transition: all 0.3s ease;
  color: white;
  font-size: 20px;
}

/* Style the social media icons with color, if you want */
.cartadd a:hover {
  background-color: #000;
}
.cartdets {
  position: fixed;
  top: 60%;
  z-index:5;
  -webkit-transform: translateY(-50%);
  -ms-transform: translateY(-50%);
  transform: translateY(-50%);
  background:black;
  color:white;
  padding:15px;
}

/* Style the icon bar links */
.cartdets a {
  display: block;
  text-align: center;
  padding: 16px;
  transition: all 0.3s ease;
  color: white;
  font-size: 20px;
}

/* Style the social media icons with color, if you want */
.cartdets a:hover {
  background-color: #000;
}
.subs_popup {
padding:20px;
color:gray;
	display: block;
	background-color: rgba(255,255,255,0.85);
	position: absolute;
top: 150px;
left:100px;
	height: 400px;
	width: 600px;
z-index: 5;
} 
#results{display:none;
background:gray;} 
#close_popup{float:right;}
</style>
  </head><body>
  <?
  error_reporting(0);
  ?>