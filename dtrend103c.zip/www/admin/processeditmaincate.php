<?
include "../../config.php";
$ptype = $_POST['type'];
$id = $_POST['id'];
echo "$ptype added to data<br>"; 
$sq = ("UPDATE mainprodcate SET mcate_title ='$ptype' WHERE id = '$id'");       
$res = mysqli_query($conn, $sq);
?>
