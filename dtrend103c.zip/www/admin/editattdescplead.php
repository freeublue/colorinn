


<?
require "bootstraptop.php";
require "slide.php";
?>

<div class='container'>
<div class='row'>
<div class='col-12'>
<?
include "../../bootlib.php";
include "../../config.php";
$sqlp = mysqli_query($conn, "SELECT * FROM attdec LIMIT 0, 30 ");
while($row = mysqli_fetch_assoc($sqlp ) ) { 
$xd = dd . $row[id]; 
echo "$row[ad_title]<br>";
echo "$row[ad_nameid]<br>";
echo "$row[ad_type]<br>"; 
echo "<a href='editattdescp.php?id=$row[id]'>Edit</a><br>";




} 
?>











</div></div>
</div></body></html>