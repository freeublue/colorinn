<?


include "../../config.php";
$ptype = $_REQUEST['ty'];
$sq = "DELETE FROM mainprodcate WHERE id  = '$ptype'";       
if (mysqli_query($conn, $sq))
  {
  echo "Table $tablename created successfully";
  }
else
  {
  echo "Error creating table: " . mysqli_error($conn);
  }



echo "$ptype deleted from data<br>"; 


?>
