<?
require "bootstraptop.php";
require "slide.php";
?>
<style>
#results{ 
display:none;

} 
#myid { 
display:none;
} 
</style>
<div class='container'>
<div class='row'>
<div class='col-12'>
<?
include "../../bootlib.php";
include "../../config.php";
echo "<div class='container'>
<div class='row'>";
echo "<div class='col-6'>";
$id = $_REQUEST['id'];
$sqlp = mysqli_query($conn, "SELECT * FROM attdec WHERE id = '$id' ");
while($row = mysqli_fetch_assoc($sqlp ) ) { 

echo "$row[ad_title]<br>";
echo "$row[ad_nameid]<br>";
echo "$row[ad_type]<br>"; 
echo "$row[ad_att1]<br>";
echo "$row[ad_att1price]<br>";



echo "$row[ad_att2]<br>";
echo "$row[ad_att2price]<br>";


echo "$row[ad_att3]<br>";
echo "$row[ad_att3price]<br>";


echo "$row[ad_att4]<br>";
echo "$row[ad_att4price]<br>";



echo "$row[ad_att5]<br>";
echo "$row[ad_att5price]<br>";



echo "$row[ad_att6]<br>";
echo "$row[ad_att6price]<br>";



echo "$row[ad_att7]<br>";
echo "$row[ad_att7price]<br>";



echo "$row[ad_att8]<br>";
echo "$row[ad_att8price]<br>";
echo "<form action='processeditattdescp.php' method='post'>";
echo "<label>Attribute name</label><br>";
echo "<input type='text' value='$row[ad_title]' name='ad_title' /><br>";

echo "<label>Attribute Type</label><br>
      <select name='ad_type'>
      <option value='NoAdd'>No Added Costs</option>
      <option value='AddIn'>Add In Costs</option>
      </select><br>";

echo "<label>Attribute Value 1</label>";
echo "<input type='text' value='$row[ad_att1]' name='ad_att1' /><br>";
echo "<label>Attribute Price 1</label>";
echo "<input type='text' value='$row[ad_att1price]' name='ad_att1price' /><br>";


echo "<label>Attribute Value 2</label>";
echo "<input type='text' value='$row[ad_att2]' name='ad_att2' /><br>";
echo "<label>Attribute Price 2</label>";
echo "<input type='text' value='$row[ad_att2price]' name='ad_att2price' /><br>";



echo "<label>Attribute Value 3</label>";
echo "<input type='text' value='$row[ad_att3]' name='ad_att3' /><br>";
echo "<label>Attribute Price 3</label>";
echo "<input type='text' value='$row[ad_att3price]' name='ad_att3price' /><br>";




echo "<label>Attribute Value 4</label>";
echo "<input type='text' value='$row[ad_att4]' name='ad_att4' /><br>";
echo "<label>Attribute Price 4</label>";
echo "<input type='text' value='$row[ad_att4price]' name='ad_att4price' /><br>";



echo "<label>Attribute Value 5</label>";
echo "<input type='text' value='$row[ad_att5]' name='ad_att5' /><br>";
echo "<label>Attribute Price 5</label>";
echo "<input type='text' value='$row[ad_att5price]' name='ad_att5price' /><br>";



echo "<label>Attribute Value 6</label>";
echo "<input type='text' value='$row[ad_att6]' name='ad_att6' /><br>";
echo "<label>Attribute Price 6</label>";
echo "<input type='text' value='$row[ad_att6price]' name='ad_att6price' /><br>";



echo "<label>Attribute Value 7</label>";
echo "<input type='text' value='$row[ad_att7]' name='ad_att7' /><br>";
echo "<label>Attribute Price 7</label>";
echo "<input type='text' value='$row[ad_att7price]' name='ad_att7price' /><br>";



echo "<label>Attribute Value 8</label>";
echo "<input type='text' value='$row[ad_att8]' name='ad_att8' /><br>";
echo "<label>Attribute Price 8</label>";
echo "<input type='text' value='$row[ad_att8price]' name='ad_att8price' /><br>";


echo "<label>Attribute Value 9</label>";
echo "<input type='text' value='$row[ad_att9]' name='ad_att9' /><br>";
echo "<label>Attribute Price 9</label>";
echo "<input type='text' value='$row[ad_att9price]' name='ad_att9price' /><br>";


echo "<label>Attribute Value 10</label>";
echo "<input type='text' value='$row[ad_att10]' name='ad_att10' /><br>";
echo "<label>Attribute Price 10</label>";
echo "<input type='text' value='$row[ad_att10price]' name='ad_att10price' /><br>";



echo "<label>Attribute Value 11</label>";
echo "<input type='text' value='$row[ad_att11]' name='ad_att11' /><br>";
echo "<label>Attribute Price 11</label>";
echo "<input type='text' value='$row[ad_att11price]' name='ad_att11price' /><br>";


echo "<label>Attribute Value 12</label>";
echo "<input type='text' value='$row[ad_att12]' name='ad_att12' /><br>";
echo "<label>Attribute Price 12</label>";
echo "<input type='text' value='$row[ad_att12price]' name='ad_att12price' /><br>"; 
echo "<input type='text' value='$row[id]' name='id' /><br>"; 
} 
echo "<input type='submit' name='submit' value='submit' /></form>";

echo "</div>
<div class='col-6'>";
echo "<h4>Edit Attribute Descriptions</h4><p></p><br />";
$sqlp = mysqli_query($conn, "SELECT * FROM attdec");
while($row = mysqli_fetch_assoc($sqlp ) ) { 
$xd = dd . $row[id];
echo "<span><a href='editattdec.php?ty=$row[id]'><i class='far fa-edit'></i> $row[ad_title] </a></span>|<i id='$row[id]' onclick='showurl(this.id);' class='fa fa-trash' aria-hidden='true'></i><br /><br><br>"; } 
echo "<a style='height:100px;background:black;color:white;width:150px;text-align:center;padding:10px;' id='myid' href=''> Are you Sure you want to delete<br>Delete</a></div>";

?>
</div>
</div></body></html>

   
<script>
var sid;
function showurl(sid) { 
var f = "dd" + sid;
document.getElementById("myid").style.display = "block";
document.getElementById("myid").href = "deleteattdec.php?ty="+sid;

} 

</script>




