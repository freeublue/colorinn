

<?
require "bootstraptop.php";
require "slide.php";
?>
<style>
#results{ 
display:none;

} 
#myid { 
display:none;
} 
</style>
<div class='container'>
<div class='row'>
<div class='col-12'>
<?
include "../../bootlib.php";
include "../../config.php";
echo "<div class='container'>
<div class='row'>";
$pid = $_REQUEST[ty];
echo "<div class='col-6'>";
echo "<form action='processeditshipdec.php' method='post'>";
echo "<label>Shiping Category</label><br>";
echo "<select name='sh_title'>";
$sqlp = mysqli_query($conn, "SELECT * FROM shipname LIMIT 0, 30 ");
while($rowa = mysqli_fetch_assoc($sqlp ) ) { 
echo "<option value='$rowa[shn_title]|$rowa[id]'>$rowa[shn_title]</option>"; 
} 
echo "</select><br>";
$sqlp = mysqli_query($conn, "SELECT * FROM shipdec WHERE id = '$pid'");
while($row = mysqli_fetch_assoc($sqlp ) ) { 

echo "<label>Shipping Sub-Title</label>";
echo "<input type='text' value='$row[sh_subtitle]' name='sh_subtitle' /><br>";

echo "<label>Shipping Description</label>";
echo "<textarea rows='20' cols='20' name='sh_descp' >$row[sh_descp]</textarea><br>";

echo "<label>Shipping Type </label><br>
      <select name='ad_type'>
      <option value='Free'>Free</option>
      <option value='Paid'>Paid</option>
      </select><br>";

echo "<label>Shipping Location 1</label>";
echo "<input type='text' value='$row[sh_att1]' name='sh_att1' /><br>";
echo "<label>Shipping Price 1</label>";
echo "<input type='text' value='$row[sh_att1price]'name='sh_att1price' /><br>";



echo "<label>Shipping Location 2</label>";
echo "<input type='text' value='$row[sh_att2]' name='sh_att2' /><br>";
echo "<label>Shipping Price 2</label>";
echo "<input type='text' value='$row[sh_att2price]' name='sh_att2price' /><br>";








echo "<label>Shipping Location 3</label>";
echo "<input type='text' value='$row[sh_att3]' name='sh_att3' /><br>";
echo "<label>Shipping Price 3</label>";
echo "<input type='text' value='$row[sh_att3price]' name='sh_att3price' /><br>";





echo "<label>Shipping Location 4</label>";
echo "<input type='text' value='$row[sh_att4]' name='sh_att4' /><br>";
echo "<label>Shipping Price 4</label>";
echo "<input type='text' value='$row[sh_att4price]' name='sh_att4price' /><br>";





echo "<label>Shipping Location 5</label>";
echo "<input type='text' value='$row[sh_att5]' name='sh_att5' /><br>";
echo "<label>Shipping Price 5</label>";
echo "<input type='text' value='$row[sh_att5price]' name='sh_att5price' /><br>";




echo "<label>Shipping Location 6</label>";
echo "<input type='text' value='$row[sh_att6]' name='sh_att6' /><br>";
echo "<label>Shipping Price 6</label>";
echo "<input type='text' value='$row[sh_att6price]' name='sh_att6price' /><br>";




echo "<label>Shipping Location 7</label>";
echo "<input type='text' value='$row[sh_att7]' name='sh_att7' /><br>";
echo "<label>Shipping Price 7</label>";
echo "<input type='text' value='$row[sh_att7price]' name='sh_att7price' /><br>";




echo "<label>Shipping Location 8</label>";
echo "<input type='text' value='$row[sh_att8]' name='sh_att8' /><br>";
echo "<label>Shipping Price 8</label>";
echo "<input type='text' value='$row[sh_att8price]' name='sh_att8price' /><br>";




echo "<label>Shipping Location 9</label>";
echo "<input type='text' value='$row[sh_att9]' name='sh_att9' /><br>";
echo "<label>Shipping Price 9</label>";
echo "<input type='text' value='$row[sh_att9price]' name='sh_att9price' /><br>";


echo "<label>Shipping Location 10</label>";
echo "<input type='text' value='$row[sh_att10]' name='sh_att10' /><br>";
echo "<label>Shipping Price 10</label>";
echo "<input type='text' value='$row[sh_att10price]' name='sh_att10price' /><br>";


echo "<label>Shipping Location 11</label>";
echo "<input type='text' value='$row[sh_att11]' name='sh_att11' /><br>";
echo "<label>Shipping Price 11</label>";
echo "<input type='text' value='$row[sh_att11price]' name='sh_att11price' /><br>";



echo "<label>Shipping Location 12</label>";
echo "<input type='text' value='$row[sh_att12]' name='sh_att12' /><br>";
echo "<label>Shipping Price 12</label>";
echo "<input type='text' value='$row[sh_att12]' name='sh_att12price' /><br>"; 

echo "<input type='text' value='$row[id]' name='id' /><br>"; } 

echo "<input type='submit' name='submit' value='submit' /></form>";


?>
</div>
</div></body></html>

   
<script>
var sid;
function showurl(sid) { 
var f = "dd" + sid;
document.getElementById("myid").style.display = "block";
document.getElementById("myid").href = "deleteshipdec.php?ty="+sid;

} 

</script>






  
