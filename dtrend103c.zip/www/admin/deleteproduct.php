<?
require "bootstraptop.php";
require "slide.php";
?>

<div class='container'>
<div class='row'>
<div class='col-12'>
<?
include "../../bootlib.php";
include "../../config.php";
$id = $_REQUEST[id];
$sq = "DELETE FROM proditem1 WHERE id = '$id'";
$res = mysqli_query($conn, $sq);
?>
</div></div>
</div></body></html>