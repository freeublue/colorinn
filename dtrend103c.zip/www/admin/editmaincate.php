<?
require "bootstraptop.php";
require "slide.php";
?>
<style>
#results{ 
display:none;

} </style>
<script>
function validateForm()
{
var x=document.forms["myform"]["addtype"].value;
if (x==null || x=="")
  {
  alert("Title must be filled out");
  return false;
  } 



   



}
</script>
<div class='container'>
<div class='row'>
<div class='col-6'>
<?
include "../../lib.php";
include "../../config.php";
$id = $_REQUEST['ty'];

echo "<form action='processeditmaincate.php' method='post' name='myform'>";
$sqlp = mysqli_query($conn, "SELECT * FROM mainprodcate WHERE id = '$id'");
while($row = mysqli_fetch_assoc($sqlp ) ) { 
echo "<h4>Enter Type</h4><p>Types serve as categories. Each group may be inserted into a matching categories. </p><br />";

           echo "<input name='addtype' value='$row[mcate_title]' type='text'>"; } 
           echo "<input type='text' name='id' value='$id' />";
               
                  echo "<button id='add_em' class='btn btn-primary' type='submit'> 
                     Go! 
                  </button></form>"; 


?>
</div>
<div class='col-6'>


?>

</div>
</div>











</div>
<div class='col-6'>



</div>
</div>




