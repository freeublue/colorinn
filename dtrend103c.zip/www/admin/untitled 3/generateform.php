<?
function genrawform ($input, $sele, $textarea, $date, $email, $number, $txtfile, $checkbox) { 
$fp = fopen($txtfile, "w");

$begin = "<form name='' id='' action='' method='' onsubmit=''>";
if($input > 0 ) { 
for($i=0;$i<$input;$i++) { 
$arrinput[] = "<label></label><br><input type='text' name='' value='' placeholder ='' /><br>" . "\n";
} }
if($date > 0 ) { 
for($i=0;$i<$date;$i++) { 
$arrinput1[] = "<label></label><br><input type='date' name='' value='' placeholder='' /><br>" . "\n";
} } 
for($i=0;$i<$email;$i++) { 
$arrinput2[] = "<label></label><br><input type='email' id='' name='' value='' placeholder ='' /><br>" . "\n";
}
for($i=0;$i<$number;$i++) { 
$arrinput2[] = "<label></label><br><input type='number' id='' name='' value='' placeholder ='' /><br>" . "\n";
}
for($i=0;$i<$textarea;$i++) { 
$arrinput3[] = "<label></label><br><textarea id='' rows='30' cols='30' name=''></textarea><br>";
}

for($i=0;$i<$sele;$i++) { 
$arrinput4[] = "<label></label><br><select id='' name=''><br>
             <option value=''>Default</option>
              <option value=''></option>
               <option value=''></option>
               </select><br>" . "\n";
}
$en = "<input type='submit' name='submit' value='submit' />"; 

$inputarraystr = implode(",", $arrinput);
if(count($arrinput1) > 0)  { 
$datearraystr = implode(",", $arrinput1); } 
$emailarraystr = implode(",", $arrinput2);
if(count($arrimput3) > 0) { 
$textareaarraystr = implode(",", $arrinput3); } 
$selearraystr = implode(",", $arrinput4);
$str = $begin . $inputarraystr . $datearraystr . $emailarraystr . $textareaarraystr . $selearraystr . $en;
fwrite($fp, $str);

} 
//input, $sele, $textarea, $date, $email, $number, $txtfile, $checkbox
//sm_title, sm_link, icon, colour, size
//mss_title, mss_body, mss_from, mss_to, mss_status
genrawform (1, 0, 1, 0, 0, 0, "messageform.txt", 0);
