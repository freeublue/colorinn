<form name='' id='' action='' method='' onsubmit=''><label></label><br><input type='text' name='' value='' placeholder ='' /><br>
<label></label><br><input type='text' name='' value='' placeholder ='' /><br>
<label></label><br><input type='text' name='' value='' placeholder ='' /><br>
<label></label><br><input type='text' name='' value='' placeholder ='' /><br>
<label></label><br><input type='email' id='' name='' value='' placeholder ='' /><br>
<label></label><br><input type='email' id='' name='' value='' placeholder ='' /><br>
<label></label><br><textarea id='' rows='30' cols='30' name=''></textarea><br>
<label></label><br><textarea id='' rows='30' cols='30' name=''></textarea><br><label></label><br><select id='' name=''><br>
             <option value=''>Default</option>
              <option value=''></option>
               <option value=''></option>
               </select><br>
<label></label><br><select id='' name=''><br>
             <option value=''>Default</option>
              <option value=''></option>
               <option value=''></option>
               </select><br>
<label></label><br><select id='' name=''><br>
             <option value=''>Default</option>
              <option value=''></option>
               <option value=''></option>
               </select><br>
<input type='submit' name='submit' value='submit' />