<?

$fields = "it_title,
it_maincate,
it_cate1,
it_cate2,
it_subtitle,
it_descp,
it_status,
it_quantity,
it_mainimage,
it_mainpricd,
it_brand,
it_stocknumber,
it_substocknumber,
it_SKU,
it_subimage1,
it_subimage2,
it_subimage3,
it_subimage4,
it_subimage5,
it_subimage6,
it_subimage7,
it_subimage8,
it_discountstatus,

it_shipping_type1,
it_shipping_typeid1,

it_shipping_type2,
it_shipping_typeid2,

it_shipping_type3,
it_shipping_typeid3,

it_shipping_type4,
it_shipping_typeid4,

it_shipping_type5,
it_shipping_typeid5,

it_shipping_type6,
it_shipping_typeid6,

it_shipping_type7,
it_shipping_typeid7,

it_shipping_type8,
it_shipping_typeid8,

it_shipping_type9,
it_shipping_typeid9,

it_shipping_type10,
it_shipping_typeid10,

it_shipping_type11,
it_shipping_typeid11,

it_shipping_type12,
it_shipping_typeid12,
it_att_type1,
it_att_typeid1,

it_att_type2,
it_att_typeid2,

it_att_type3,
it_att_typeid3,

it_att_type4,
it_att_typeid4,

it_att_type5,
it_att_typeid5,

it_att_type6,
it_att_typeid6,

it_att_type7,
it_att_typeid7,

it_att_type8,
it_att_typeid8,

it_att_type9,
it_att_typeid9,

it_att_type10,
it_att_typeid10,

it_att_type11,
it_att_typeid11,

it_att_type12,
it_att_typeid12,
it_downloadtype,
it_downloadname,
it_downloadlink,
it_volweight,

it_dateadded,
it_expirydate";
function genrawpost($fields) { 
$file = 'postfile.txt';
$postfields = explode(",", $fields);
print_r($postfields);
$count = count($postfields);
for($i=0;$i<$count;$i++) { 
$ele[$i] = '$' . trim($postfields[$i]) . ' = $_POST[' . "'" . trim($postfields[$i]) . "'" . '];' . "\n";
$fp = fopen($file, "a+");
fwrite($fp, $ele[$i]);
$fstr[$i] = "'$" . trim($postfields[$i]) . "'";
} 
$fieldsstr = implode(",", $fstr);
$ins = '$sq = $db->query("INSERT INTO ' . $table . '(' . $fields . ')' . ' VALUES(' . $fieldsstr . ')");';
$fp2 = fopen($file, "a+");
fwrite($fp2, $ins);
}
genrawpost($fields);