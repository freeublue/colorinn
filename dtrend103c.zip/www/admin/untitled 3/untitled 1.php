pr_firstname, pr_lastname, pr_street, pr_suburb, pr_town, pr_state, pr_zip, pr_mobilenumber, pr_email, pr_dateofbirth, pr_cate1, pr_cate2
<?

$fields = "pr_firstname, pr_lastname, pr_street, pr_suburb, pr_town, pr_state, pr_zip, pr_mobilenumber, pr_email, pr_dateofbirth, pr_cate1, pr_cate2";
function genrawpost($fields) { 
$file = 'projectpostfile.txt';
$postfields = explode(",", $fields);
print_r($postfields);
$count = count($postfields);
for($i=0;$i<$count;$i++) { 
$ele[$i] = '$' . trim($postfields[$i]) . ' = $_POST[' . "'" . trim($postfields[$i]) . "'" . '];' . "\n";
$fp = fopen($file, "a+");
fwrite($fp, $ele[$i]);
$fstr[$i] = "'$" . trim($postfields[$i]) . "'";
} 
$fieldsstr = implode(",", $fstr);
$ins = '$sq = $db->query("INSERT INTO ' . $table . '(' . $fields . ')' . ' VALUES(' . $fieldsstr . ')");';
$fp2 = fopen($file, "a+");
fwrite($fp2, $ins);
}
genrawpost($fields);