prodcate1(id INT 
NOT NULL
AUTO_INCREMENT,
PRIMARY KEY(id),
pcate_maincateid INT, pcate_title 
<?
include "../../config.php";
$ptype = $_POST['type'];
$maincateid = $_POST['cate'];
echo "$ptype added to data<br>"; 
$sq = ("INSERT INTO prodcate1(pcate_maincateid, pcate_title) values('$maincateid', '$ptype')");       
$res = mysqli_query($conn, $sq);
?>

