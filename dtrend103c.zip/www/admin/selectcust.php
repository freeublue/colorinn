


<?
require "bootstraptop.php";
require "slide.php";
?>

<div class='container'>
<div class='row'>
<div class='col-12'>
<?
include "../functions/libsql.php";
include "../../config.php";
$sqlp = mysqli_query($conn, "SELECT * FROM cust1");
while($row = mysqli_fetch_assoc($sqlp ) ) { 
$xd = dd . $row[id]; 
$emvv =  cr($stp, ($row['cu_email']), $action = 'inv');
$ph =  cr($stp, ($row['cu_phone_mobile']), $action = 'inv');

echo "$emvv<br>";
echo "$row[id]<br>";
echo "$ph<br>"; 




} 
?>









</div></div>
</div></body></html>