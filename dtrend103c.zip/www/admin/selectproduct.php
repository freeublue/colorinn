


<?
require "bootstraptop.php";
require "slide.php";
?>

<div class='container'>
<div class='row'>
<div class='col-12'>
<?
include "../../bootlib.php";
include "../../config.php";
$sqlp = mysqli_query($conn, "SELECT * FROM proditem1");
while($row = mysqli_fetch_assoc($sqlp ) ) { 
$xd = dd . $row[id]; 
echo "$row[id]<a href='deleteproduct.php?id=$row[id]'>Delete</a><br>";
echo "$row[it_title]<br>";
echo "$row[it_maincate]<br>";
echo "$row[it_cate1]<br>"; 
echo "$row[it_cate2]<br>";
echo "$row[it_subtitle]<br>";



echo "$row[it_descp]<br>";
echo "$row[it_status]<br>";


echo "$row[it_quantity]<br>";
echo "$row[it_mainpricd]<br>";


echo "$row[it_brand]<br>";
echo "$row[it_shipping_type1]<br>";



echo "$row[it_att_type1]<br>";
echo "$row[it_att_type2]<br>";



echo "$row[ad_att6]<br>";
echo "$row[ad_att6price]<br>";



echo "$row[ad_att7]<br>";
echo "$row[ad_att7price]<br>";



echo "$row[ad_att8]<br>";
echo "$row[ad_att8price]<br>";



} 
?>
, ad_type, ad_att1, ad_att1price, ad_att2, ad_att2price, ad_att3, ad_att3price, ad_att4, ad_att4price, ad_att5, ad_att5price, ad_att6, ad_att6price, ad_att7, ad_att7price, ad_att8, ad_att8price, ad_att9, ad_att9price, ad_att10, ad_att10price, ad_att11, ad_att11price, ad_att12, ad_att12price

 proditem1(id INT 
NOT NULL
AUTO_INCREMENT,
PRIMARY KEY(id),
it_title VARCHAR(255),
it_maincate VARCHAR(255),
it_cate1 VARCHAR(255),
it_cate2 VARCHAR(255), 
it_subtitle VARCHAR(255),
it_descp VARCHAR(255),
it_status VARCHAR(255),
it_quantity VARCHAR(255),
it_mainimage VARCHAR(255),
it_mainpricd VARCHAR(255),
it_brand VARCHAR(255),
it_stocknumber VARCHAR(255),
it_substocknumber VARCHAR(255),
it_SKU VARCHAR(255), 
it_discountname1 VARCHAR(255),
it_discountid1 VARCHAR(255),

it_discountname2 VARCHAR(255),
it_discountid2 VARCHAR(255),

it_discountname3 VARCHAR(255),
it_discountid3 VARCHAR(255),

it_discountname4 VARCHAR(255),
it_discountid4 VARCHAR(255),

it_subimage1 VARCHAR(255),
it_subimage2 VARCHAR(255),
it_subimage3 VARCHAR(255),
it_subimage4 VARCHAR(255),
it_subimage5 VARCHAR(255),
it_subimage6 VARCHAR(255),
it_subimage7 VARCHAR(255),
it_subimage8 VARCHAR(255),
it_discountstatus VARCHAR(255),

it_shipping_type1 VARCHAR(255),
it_shipping_typeid1 VARCHAR(255),

it_shipping_type2 VARCHAR(255),
it_shipping_typeid2 VARCHAR(255),

it_shipping_type3 VARCHAR(255),
it_shipping_typeid3 VARCHAR(255),

it_shipping_type4 VARCHAR(255),
it_shipping_typeid4 VARCHAR(255), 

it_shipping_type5 VARCHAR(255),
it_shipping_typeid5 VARCHAR(255),

it_shipping_type6 VARCHAR(255),
it_shipping_typeid6 VARCHAR(255),

it_shipping_type7 VARCHAR(255),
it_shipping_typeid7 VARCHAR(255),

it_shipping_type8 VARCHAR(255),
it_shipping_typeid8 VARCHAR(255),

it_shipping_type9 VARCHAR(255),
it_shipping_typeid9 VARCHAR(255),

it_shipping_type10 VARCHAR(255),
it_shipping_typeid10 VARCHAR(255),

it_shipping_type11 VARCHAR(255),
it_shipping_typeid11 VARCHAR(255),

it_shipping_type12 VARCHAR(255),
it_shipping_typeid12 VARCHAR(255),







it_att_type1 VARCHAR(255),
it_att_typeid1 VARCHAR(255),

it_att_type2 VARCHAR(255),
it_att_typeid2 VARCHAR(255),

it_att_type3 VARCHAR(255),
it_att_typeid3 VARCHAR(255),

it_att_type4 VARCHAR(255),
it_att_typeid4 VARCHAR(255), 

it_att_type5 VARCHAR(255),
it_att_typeid5 VARCHAR(255),

it_att_type6 VARCHAR(255),
it_att_typeid6 VARCHAR(255),

it_att_type7 VARCHAR(255),
it_att_typeid7 VARCHAR(255),

it_att_type8 VARCHAR(255),
it_att_typeid8 VARCHAR(255),

it_att_type9 VARCHAR(255),
it_att_typeid9 VARCHAR(255),

it_att_type10 VARCHAR(255),
it_att_typeid10 VARCHAR(255),

it_att_type11 VARCHAR(255),
it_att_typeid11 VARCHAR(255),

it_att_type12 VARCHAR(255),
it_att_typeid12 VARCHAR(255),









it_downloadtype VARCHAR(255),
it_downloadname VARCHAR(255),
it_downloadlink VARCHAR(255), 
it_volweight VARCHAR(255), 

it_dateadded DATE DEFAULT '0000-00-00',
it_expirydate DATE DEFAULT '0000-00-00'
)";








</div></div>
</div></body></html>