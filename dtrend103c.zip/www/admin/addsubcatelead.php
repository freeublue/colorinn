
<?
require "bootstraptop.php";
require "slide.php";
?>
<style>
#results{ 
display:none;

} </style>
<script>
function validateForm()
{
var x=document.forms["myform"]["addtype"].value;
if (x==null || x=="")
  {
  alert("Title must be filled out");
  return false;
  } 



   



}
</script>
<div class='container'>
<div class='row'>
<div class='col-6'>
<?
include "../../lib.php";
include "../../config.php";
?>

</div>
<div class='col-6'>

<?php
echo "<h4>Edit Type</h4><p>Types serve as categories. Each group may be inserted into a matching categories. </p><br />";
$sqlp = mysqli_query($conn, "SELECT * FROM mainprodcate LIMIT 0, 30 ");
while($row = mysqli_fetch_assoc($sqlp ) ) { 

echo "<span><a href='addsubcategory.php?ty=$row[id]'><i class='far fa-plus'></i> $row[mcate_title] </a></span><br />"; } 
?>

</div>
</div>











</div>
<div class='col-6'>



</div>
</div>



