
$sql = "INSERT INTO users (name, surname, mobile, email, birthdate, ins_time) VALUES (?,?,?,?,?,?)";
$pdo->prepare($sql)->execute([$afname, $alname, $amobileno, $ema, $bdate, $day]);
<?
echo password_hash("rasmuslerdorf", PASSWORD_DEFAULT);
