<?php

\Cloudinary::config(array(
    'cloud_name' => 'swiftwebguru',
    'api_key' => '117298446482898',
    'api_secret' => 'NP1XdRxFKSdjWG68hHSZdktoDKo'
));
