<?php

namespace Cloudinary\Api;

/**
 * Class AlreadyExists
 * @package Cloudinary\Api
 */
class AlreadyExists extends Error
{
}
