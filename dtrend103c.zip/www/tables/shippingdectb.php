

<?
require "../../config.php";

$sql = "CREATE TABLE shipdec(id INT 
NOT NULL
AUTO_INCREMENT,
PRIMARY KEY(id),
sh_title VARCHAR(255),
sh_subtitle VARCHAR(255),
sh_descp TEXT,
sh_type VARCHAR(255), 
sh_att1 VARCHAR(255),
sh_att1price VARCHAR(255),

sh_att2 VARCHAR(255),
sh_att2price VARCHAR(255),

sh_att3 VARCHAR(255),
sh_att3price VARCHAR(255),

sh_att4 VARCHAR(255),
sh_att4price VARCHAR(255),

sh_att5 VARCHAR(255),
sh_att5price VARCHAR(255),

sh_att6 VARCHAR(255),
sh_att6price VARCHAR(255),

sh_att7 VARCHAR(255),
sh_att7price VARCHAR(255),

sh_att8 VARCHAR(255),
sh_att8price VARCHAR(255),

sh_att9 VARCHAR(255),
sh_att9price VARCHAR(255),

sh_att10 VARCHAR(255),
sh_att10price VARCHAR(255),

sh_att11 VARCHAR(255),
sh_att11price VARCHAR(255),

sh_att12 VARCHAR(255),
sh_att12price VARCHAR(255)
)";
print "running query";
if (mysqli_query($conn, $sql))
  {
  echo "Table prices created successfully";
  }
else
  {
  echo "Error creating table: " . mysqli_error($conn);
  }
?>