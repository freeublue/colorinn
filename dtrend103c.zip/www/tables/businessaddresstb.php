
<?
require "../functions/libsql.php";
$connection = "../../configadmin.php";
$tb = "businessaddress1";
$idfield = "busad_id";
$fieldsarray = array("nameid",
"addressname",
"address1",
"address2",
"suburb",
"town", 
"zip", 
"state", 
"landline",
"mobile", 
"startdate", "bus_lat", "bus_lng");
maketb($connection, $tb, $idfield, $fieldsarray);
?>