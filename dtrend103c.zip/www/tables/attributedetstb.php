
<?
require "../../config.php";
//do not use this table we are doing it the other way around
$sql = "CREATE TABLE attributedetails(attdets_id INT 
NOT NULL
AUTO_INCREMENT,
PRIMARY KEY(attdets_id),
attdets_title VARCHAR(255),
attdets_pricetype VARCHAR(255),
attdets_descp VARCHAR(255),
attdets_amount VARCHAR(255))";
print "running query";
if (mysqli_query($conn, $sql))
  {
  echo "Table attdets created successfully";
  }
else
  {
  echo "Error creating table: " . mysqli_error($conn);
  }
?>


