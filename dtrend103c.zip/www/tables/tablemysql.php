
<?
require "../../config.php";

$sql = "CREATE TABLE imgtb(id INT 
NOT NULL
AUTO_INCREMENT,
PRIMARY KEY(id),
im_title VARCHAR(255),
im_subhead VARCHAR(255),
im_txt VARCHAR(255),
im_image VARCHAR(255), 
im_thumb VARCHAR(255),
im_link VARCHAR(255),
im_category VARCHAR(255),
im_descp VARCHAR(255),
im_author VARCHAR(255),
im_license VARCHAR(255),
im_cate1 VARCHAR(255),
im_cate2 VARCHAR(255),
im_cate3 VARCHAR(255),
im_size1 VARCHAR(255),
im_size2 VARCHAR(255),
im_size3 VARCHAR(255),

ins_time DATE DEFAULT '0000-00-00 00:00:00')";
print "running query";
if (mysqli_query($conn, $sql))
  {
  echo "Table prices created successfully";
  }
else
  {
  echo "Error creating table: " . mysqli_error($conn);
  }
?>

im_title, im_subhead, im_txt, im_image, im_thumb, im_link, im_category, im_descp, im_author, im_licence, im_cate1, im_cate2, im_cate3, im_size1, im_size2, im_size3
