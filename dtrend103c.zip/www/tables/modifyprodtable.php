<?
require "../../config.php";
$qr = "ALTER TABLE proditem1 MODIFY it_descp TEXT";
if (mysqli_query($conn, $qr))
  {
  echo "Table prices created successfully";
  }
else
  {
  echo "Error creating table: " . mysqli_error($conn);
  }