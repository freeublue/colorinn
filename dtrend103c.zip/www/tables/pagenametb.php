
<?
include "../../configadmin.php";
   $sql =<<<EOF
      CREATE TABLE pagname
      (pn_id INTEGER NOT NULL PRIMARY KEY AUTOINCREMENT,

pn_title


);
EOF;

   $ret = $db->exec($sql);
   if(!$ret){
      echo $db->lastErrorMsg();
   } else {
      echo "Table created successfully\n";
   }
   $db->close();
?>