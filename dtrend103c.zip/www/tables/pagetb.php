
<?
include "../../configadmin.php";
   $sql =<<<EOF
      CREATE TABLE pagr1
      (ab_id INTEGER NOT NULL PRIMARY KEY AUTOINCREMENT,

ab_pagename, ab_title, ab_subhead, ab_txt, ab_image_descp, ab_image, ab_link, ab_link_descp, ab_table, ab_table_descp, ab_table_id, ab_table_formid, ab_table_fa_icon, ab_listid


);
EOF;

   $ret = $db->exec($sql);
   if(!$ret){
      echo $db->lastErrorMsg();
   } else {
      echo "Table created successfully\n";
   }
   $db->close();
?>