

<?
require "../../config.php";

$sql = "CREATE TABLE attname(id INT 
NOT NULL
AUTO_INCREMENT,
PRIMARY KEY(id),
att_title VARCHAR(255))";
print "running query";
if (mysqli_query($conn, $sql))
  {
  echo "Table attname created successfully";
  }
else
  {
  echo "Error creating table: " . mysqli_error($conn);
  }
?>