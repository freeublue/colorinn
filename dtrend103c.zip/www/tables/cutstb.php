
   

<?
require "../../config.php";

$sql = "CREATE TABLE cust1(id INT 
NOT NULL
AUTO_INCREMENT,
PRIMARY KEY(id),
cu_ps VARCHAR(255),
cu_psqu VARCHAR(255),
cu_psas VARCHAR(255),
cu_fname VARCHAR(255), 
cu_lname VARCHAR(255),
cu_contact_title VARCHAR(255),
cu_email VARCHAR(255),
cu_address_streetnum VARCHAR(255),
cu_address_streetname VARCHAR(255),
cu_address_buildingnum VARCHAR(255),
cu_address_buildingname VARCHAR(255),
cu_address_suburb VARCHAR(255),
cu_address_town VARCHAR(255),
cu_address_province VARCHAR(255),
cu_address_country VARCHAR(255),
cu_address_postalcode VARCHAR(255), 
cu_phone_land VARCHAR(255), 
cu_wh_number VARCHAR(255), 
cu_phone_mobile VARCHAR(255), 
cu_phone_fax VARCHAR(255), 
cu_descp TEXT, 
cu_type VARCHAR(255), 
cu_newsletter VARCHAR(255), 
cust_em_idcu VARCHAR(255),


cu_dayfirst DATE DEFAULT '0000-00-00 00:00:00')";
print "running query";
if (mysqli_query($conn, $sql))
  {
  echo "Table prices created successfully";
  }
else
  {
  echo "Error creating table: " . mysqli_error($conn);
  }
?>

im_title, im_subhead, im_txt, im_image, im_thumb, im_link, im_category, im_descp, im_author, im_licence, im_cate1, im_cate2, im_cate3, im_size1, im_size2, im_size3

