
<?
include "../../configadmin.php";
   $sql =<<<EOF
      CREATE TABLE locate
      (lc_id INTEGER NOT NULL PRIMARY KEY AUTOINCREMENT,

lc_title, lc_lat, lc_lng


);
EOF;

   $ret = $db->exec($sql);
   if(!$ret){
      echo $db->lastErrorMsg();
   } else {
      echo "Table created successfully\n";
   }
   $db->close();
?>