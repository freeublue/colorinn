<?
require "../functions/libsql.php";
$connection = "../../configadmin.php";;
$tb = "businessname";
$idfield = "bus_id";
$fieldsarray = array("webname" , "phrase", "logo", "backgroundimg", "industry", "producttype");
maketb($connection, $tb, $idfield, $fieldsarray);
?>