

<?
require "../../config.php";

$sql = "CREATE TABLE mainprodcate(id INT 
NOT NULL
AUTO_INCREMENT,
PRIMARY KEY(id),
mcate_title VARCHAR(255))";
print "running query";
if (mysqli_query($conn, $sql))
  {
  echo "Table mainprodcate created successfully";
  }
else
  {
  echo "Error creating table: " . mysqli_error($conn);
  }
?>