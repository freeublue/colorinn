
<?
include "../../configadmin.php";
   $sql =<<<EOF
      CREATE TABLE formtb
      (ft_id INTEGER NOT NULL PRIMARY KEY AUTOINCREMENT,

ft_title, ft_field, ft_type, ft_value, ft_description, ft_txt, ft_image


);
EOF;

   $ret = $db->exec($sql);
   if(!$ret){
      echo $db->lastErrorMsg();
   } else {
      echo "Table created successfully\n";
   }
   $db->close();
?>