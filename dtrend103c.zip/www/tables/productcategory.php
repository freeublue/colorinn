

<?
require "../../config.php";

$sql = "CREATE TABLE prodcate1(id INT 
NOT NULL
AUTO_INCREMENT,
PRIMARY KEY(id),
pcate_maincateid INT, pcate_title VARCHAR(255))";
print "running query";
if (mysqli_query($conn, $sql))
  {
  echo "Table attname created successfully";
  }
else
  {
  echo "Error creating table: " . mysqli_error($conn);
  }
?>