<?php
include "../../config.php";
$sql = "CREATE TABLE str (str_id INT 
NOT NULL
AUTO_INCREMENT,
PRIMARY KEY(str_id),
ca VARCHAR(255),
pf BLOB)";
if (mysqli_query($conn, $sql))
  {
  echo "Table str created successfully";
  }
else
  {
  echo "Error creating table: " . mysqli_error($link);
  }
?>