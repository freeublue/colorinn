<h4>Make a list</h4>
<form>
<input type='text' name='name' /><br>
<input type='text' name='heading' /><br>
<input type='text' name='subheading' /><br>
<input type='number' name='itemnumber' /><br>
<input type='text' name='type' /><br>