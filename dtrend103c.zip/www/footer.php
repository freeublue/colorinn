<div class='row text-center'>
<div class='col-4 infobox2'><p>Contact</p></div>
<div class='col-4 infobox2'><p>Contact</p></div>
<div class='col-4 infobox2'><p>Contact</p></div>

</div>