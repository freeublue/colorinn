<!doctype html>
<html lang="en">
  <head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
    <meta name="description" content="">
    <meta name="author" content="">
    <link rel="icon" href="../../../../favicon.ico">
<?

    echo "<title>$title</title>";
    ?>

    <!-- Bootstrap core CSS -->

    <!-- Bootstrap core CSS --><link href="https://stackpath.bootstrapcdn.com/bootstrap/4.1.3/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-MCw98/SFnGE8fJT3GXwEOngsV7Zt27NXFoaoApmYm81iuXoPkFOJwJ8ERdknLPMO" crossorigin="anonymous"><link href="https://fonts.googleapis.com/css?family=Merriweather:400,900i" rel="stylesheet"><link href="css/style.css" rel="stylesheet"><link href="animate.css" rel="stylesheet"><link rel="stylesheet" href="https://use.fontawesome.com/releases/v5.3.1/css/all.css" integrity="sha384-mzrmE5qonljUremFsqc01SB46JvROS7bZs3IO2EmfFsd15uHvIt+Y8vEf7N7fWAU" crossorigin="anonymous">

</head><body onload='type();'><div style='background:#437AB8;height:70px;' class='icon-bar'><p id='cart'></p><a href='cartdets.php'><i class="fas fa-shopping-cart fa-1x" style='color:#F8F8F8;'></i></a></div><div class='cartadd'>add</div><div class='cartdets'>Details</div>
 <?
 error_reporting(0);
 ?>