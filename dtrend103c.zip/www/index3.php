<?
session_start();

require "bootstraptop2.php";
require "functions/bootlib.php";
echo "<div class='container-fluid'><div id='section1' class='row'><div class='col-2'><img src='logoa.png' /></div><div class='col-2'><b></b></div><div class='col-2'><b></b></div>
<div class='col-2'><p><a style='text-decoration:none;color:white;' href='register.php'>Register</a></p></div><div class='col-2'><p>My Account</p></div><div class='col-2'><form id='bo'><label>Search</label><br><input  type='text' name='nlet' /></form></div></div></div>";
$size = 'xl';
$bootcolor = 'light';
$bootcolor2 = 'light';
$navname = 'Home';
$pagelinkarray = array("contact.php" => "Contact", "about.php" => "About", "deals.php" => "Hot Deals", "login.php" => "Login", );
$ar = array('Categories ', 'categories.php');
navbar ($size, $bootcolor, $bootcolor2, $navname, $pagelinkarray, $ar);


?>


<div class='container-fluid'>
<div class='row'><div id='headimage1' class='col-12 text-center'><h1 style='margin-top:550px;' id='demo'></h1><h4 style='margin-top:30px;'>Trendy Audio</h4><p><a class="btn btn-md btn-dark" href="register.php" role="button">Shop Now</a></p><p style='margin-top:50px;'>Quality Guarantee</p>
</div>
</div>
<div class='row'>
<div class="col-2 text-center infobox"><i style='margin-top:3em;' class="fas fa-shipping-fast fa-2x"></i></div>
<div class="col-2 text-center infobox"><h6 class='text-center' style='margin-top:3em;width:100px;'>FAST SAFE DELIVERY</h6><p style='margin-top:1em;width:100px;color:#5E9C1C;'>

Free shipping on all orders over R1000</p>
</div>

<div class="col-2 text-center infobox"><i style='margin-top:3em;' class="fas fa-hand-holding-usd fa-2x"></i></div>
<div class="col-2 text-center infobox"><h6 style='margin-top:3em;'>MONEY BACK GUARANTEE</h6><p style='margin-top:1em;width:100px;color:#5E9C1C;'>
100% money back guarantee</p>
</div>
<div class="col-2 text-center infobox"><i style='margin-top:3em;' class="fas fa-clock fa-2x"></i></div>
<div class="col-2 text-center infobox"><h6 style='margin-top:3em;'>AFTER SALES SUPPORT</h6><p style='margin-top:1em;width:100px;color:#5E9C1C;'>
Call, WhatsApp, SMS or email us</p>
</div>
</div>
          <div class='row'>
          <div class='col-6 text-center'><table style='margin-left:40px;margin-top:3em;text-align:center;' width='250px' class='table-bordered'>
<tr style='height:80px;'><th>Categories</th></tr>
<tr style='height:50px;'><td>Audio       >>  </td></tr>
<tr style='height:50px;'><td>Drones      >>  </td></tr>
<tr style='height:50px;'><td>Bundles     >>  </td></tr>
<tr style='height:50px;'><td>Power Banks >> </td></tr>
</table>
           </div>
           

          
          <div id='headimage' class='col-6'>
           </div>
           </div>
<div style='margin-bottom:3em;' class='row'>



<div class="col-4 text-center infobox4"><h6 style='margin-top:3em;'>SPECIAL OFFER</h6><h2>10%</h2><p>Off JJJ Headphones</p><p><img class='img-fluid mx-auto d-block' style='height:160px' src='camera.png' ></p>
</div>


<div class="col-4 text-center infobox4"><h6 style='margin-top:3em;'>SALE</h6><h2>5%</h2><p>Off power banks</p><p><img class='img-fluid mx-auto d-block' style='height:160px' src='powerbank.png' ></p>
</div>

<div class="col-4 text-center infobox4"><h6 style='margin-top:3em;'>DEALS</h6><h2>5%</h2><p> Off Cameras</p><p><img class='img-fluid mx-auto d-block' style='height:160px' src='camera.png' ></p>
</div>
</div>


<div class='row'>



<div class="col-12 text-center"><h2>Featured</h2><hr>
</div>
</div>


<div class='row'>



<div class="col-4 text-center">
 <div class="card">
     <div style='color:#437AB8;' class='card-header text-center'>Headphones</div>
      <img style='width:100px;text-align:center;' class='card-img-top mx-auto d-block' src='hph.png' alt='$rowx[ab_title]'>
    
    <div class='card-body'>
      <h5 style='color:#5E9C1C;' class='card-title'>Awesome Sound</h5>
      <p style='color:#ceb7a2;' class='card-text'>Some text</p><p><a style='background:#437AB8;color:white;' class="btn btn-sm" href="cart.php" role="button">Add to Cart</a></p>
    </div>
    <div style='color:#5E9C1C;' class='card-footer text-center'>
      <h4  class='text-muted text-center'>R1700</h4>
    </div>
  </div>
</div>
  <div class="col-4 text-center">
 <div class="card">
     <div style='color:#437AB8;' class='card-header text-center'>Headphones</div>
      <img style='width:100px;text-align:center;' class='card-img-top mx-auto d-block' src='hph.png' alt='$rowx[ab_title]'>
    
    <div class='card-body'>
      <h5 style='color:#5E9C1C;' class='card-title'>Awesome Sound</h5>
      <p style='color:#ceb7a2;' class='card-text'>Some text</p><p><a style='background:#437AB8;color:white;' class="btn btn-sm" href="cart.php" role="button">Add to Cart</a></p>
    </div>
    <div class='card-footer text-center'>
      <h4 class='text-muted text-center'>R1700</h4>
    </div>
  </div>
</div>
  <div class="col-4 text-center">
 <div class="card">
     <div style='color:#437AB8;' class='card-header text-center'>Headphones</div>
      <img style='width:100px;text-align:center;' class='card-img-top mx-auto d-block' src='hph.png' alt='$rowx[ab_title]'>
    
    <div class='card-body'>
      <h5 style='color:#5E9C1C;' class='card-title'>Awesome Sound</h5>
      <p style='color:#ceb7a2;' class='card-text'>Some text</p><p><a style='background:#437AB8;color:white;' class="btn btn-sm" href="cart.php" role="button">Add to Cart</a></p>
    </div>
    <div class='card-footer text-center'>
      <h4 class='text-muted text-center'>R1700</h4>
    </div>
  </div>
</div>


</div><!row>


<div class='row'>



<div class="col-4 text-center">
 <div class="card">
     <div style='color:#437AB8;' class='card-header text-center'>Headphones</div>
      <img style='width:100px;text-align:center;' class='card-img-top mx-auto d-block' src='hph.png' alt='$rowx[ab_title]'>
    
    <div class='card-body'>
      <h5 style='color:#5E9C1C;' class='card-title'>Awesome Sound</h5>
      <p style='color:#ceb7a2;' class='card-text'>Some text</p><p><a style='background:#437AB8;color:white;' class="btn btn-sm" href="cart.php" role="button">Add to Cart</a></p>
    </div>
    <div class='card-footer text-center'>
      <h4 class='text-muted text-center'>R1700</h4>
    </div>
  </div>
</div>
  <div class="col-4 text-center">
 <div class="card">
     <div style='color:#437AB8;' class='card-header text-center'>Headphones</div>
      <img style='width:100px;text-align:center;' class='card-img-top mx-auto d-block' src='hph.png' alt='$rowx[ab_title]'>
    
    <div class='card-body'>
      <h5 style='color:#5E9C1C;' class='card-title'>Awesome Sound</h5>
      <p style='color:#ceb7a2;' class='card-text'>Some text</p><p><a style='background:#437AB8;color:white;' class="btn btn-sm" href="cart.php" role="button">Add to Cart</a></p>
    </div>
    <div class='card-footer text-center'>
      <h4 class='text-muted text-center'>R1700</h4>
    </div>
  </div>
</div>
  <div class="col-4 text-center">
 <div class="card">
     <div style='color:#437AB8;' class='card-header text-center'>Headphones</div>
      <img style='width:100px;text-align:center;' class='card-img-top mx-auto d-block' src='hph.png' alt='$rowx[ab_title]'>
    
    <div class='card-body'>
      <h5 style='color:#5E9C1C;' class='card-title'>Awesome Sound</h5>
      <p style='color:#ceb7a2;' class='card-text'>Some text</p><p><a style='background:#437AB8;color:white;' class="btn btn-sm" href="cart.php" role="button">Add to Cart</a></p>
    </div>
    <div class='card-footer text-center'>
      <h4 class='text-muted text-center'>R1700</h4>
    </div>
  </div>
</div>


</div><!row>
<div class='row'>



<div class="col-4 text-center infobox2">
</div>


<div class="col-4 text-center infobox2">
</div>

<div class="col-4 text-center infobox2">
</div>
</div>


           
           






<? 
require "footer.php";
?>




</div><!container>

<?
require "bootstrapbottom.php";
?>
<script>
var i = 0;
var txt = 'Awesome';
var speed = 250;

function type() {
  if (i < txt.length) {
    document.getElementById("demo").innerHTML += txt.charAt(i);
    i++;
    setTimeout(type, speed);
  }
}
</script>