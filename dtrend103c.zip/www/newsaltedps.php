<?
$password = 'helloworld';
$hashed_password = password_hash($password, PASSWORD_DEFAULT);




$pass = 'helloworld';
if(password_verify($pass, $hashed_password)) {
    // If the password inputs matched the hashed password in the database
    // Do something, you know... log them in.
echo "correct";
} else { 
echo "no";
} 


// Else, Redirect them back to the login page.