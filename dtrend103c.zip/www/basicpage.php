<?
session_start();

require "bootstraptop.php";
require "functions/bootlib.php";
require "../config.php";
$size = 'xl';
$bootcolor = 'dark';
$bootcolor2 = 'dark';
$navname = 'name of site';
$pagelinkarray = array("contact.php" => "Contact", "about.php" => "About", "login.php" => "Login", "register.php" => "Register", "pricing.php" => "Pricing");
$ar = array('Categories >>', 'categories.php');
navbar ($size, $bootcolor, $bootcolor2, $navname, $pagelinkarray, $ar);

if(isset($_SESSION[customer]) ) {  
?>
<div class='container-fluid'>






<? } 

else { echo "You must be logged in to proceed"; } 
require "footer.php";
?>




</div><!container>

<?
require "bootstrapbottom.php";
?>