<?
session_start();

require "bootstraptop.php";
require "functions/bootlib.php";
require "../config.php";
$size = 'xl';
$bootcolor = 'dark';
$bootcolor2 = 'dark';
$navname = 'Home';
$pagelinkarray = array("contact.php" => "Contact", "about.php" => "About", "login.php" => "Login", "register.php" => "Register", "pricing.php" => "Pricing");
$ar = array('Categories ', 'categories.php');
navbar ($size, $bootcolor, $bootcolor2, $navname, $pagelinkarray, $ar);


?>
<div class='container-fluid'>

          <div id='section1' class='row'>
          <div class='col-12'><h1>Awesome</h1>
          <form id='bo'><label>Get Our Newsletter</label><br>
          <input  type='text' name='nlet' /></form>
           </div>
           </div>
          <div class='row'>
          <div id='headimage' class='col-12'>
           </div>
           </div>
<div  class='row text-center'>
          <div style='height: 200px;
background:red;
color:gray;width:80%;' class='col-4 infobox'><p>Confidence</p>
           </div>
           <div style='height: 200px;
background:red;
color:gray;' class='col-4 infobox'><p>Confidence</p>
           </div>
            <div style='height: 200px;
background:#EEEEEE;
color:gray;' class='col-4 infobox'><p>Confidence</p>
           </div>
           </div>
          <div id='section1' class='row'>
          <div class='col-12'><h1>Awesome</h1>
          
           </div>
           </div>
<div  class='row text-center'>
          <div style='height: 200px;
background:#EEEEEE;
color:gray;width:80%;' class='col-4 infobox'><p>Confidence</p>
           </div>
           <div style='height: 200px;
background:#EEEEEE;
color:gray;' class='col-4 infobox'><p>Confidence</p>
           </div>
            <div style='height: 200px;
background:red;
color:gray;' class='col-4 infobox'><p>Confidence</p>
           </div>
           </div>



<div class='row'>




  <div class="col-4">

 <div class="card">
     <div class='card-header text-center'>$rowx[ab_title]</div>
      <img class='card-img-top img-fluid' src='hph.png' style='width:160px;text-align:center;' alt='$rowx[ab_title]'>
    
    <div class='card-body'>
      <h5 class='card-title'>$rowx[ab_subhead]</h5>
      <p style='color:#ceb7a2;' class='card-text'>$rowx[ab_txt]</p>
    </div>
    <div class='card-footer text-center'>
      <h4 class='text-muted text-center'>$rowx[ab_date]</h4>
    </div>
  </div>
</div>





  <div class="col-4">
 <div class="card">
     <div class='card-header text-center'>$rowx[ab_title]</div>
      <img class='card-img-top img-fluid' src='$rowx[ab_image]' alt='$rowx[ab_title]'>
    
    <div class='card-body'>
      <h5 class='card-title'>$rowx[ab_subhead]</h5>
      <p style='color:#ceb7a2;' class='card-text'>$rowx[ab_txt]</p>
    </div>
    <div class='card-footer text-center'>
      <h4 class='text-muted text-center'>$rowx[ab_date]</h4>
    </div>
  </div>
</div>

  <div class="col-4">
 <div class="card">
     <div class='card-header text-center'>$rowx[ab_title]</div>
      <img class='card-img-top img-fluid' src='$rowx[ab_image]' alt='$rowx[ab_title]'>
    
    <div class='card-body'>
      <h5 class='card-title'>$rowx[ab_subhead]</h5>
      <p style='color:#ceb7a2;' class='card-text'>$rowx[ab_txt]</p>
    </div>
    <div class='card-footer text-center'>
      <h4 class='text-muted text-center'>$rowx[ab_date]</h4>
    </div>
  </div>
</div>

</div><!row>


           
           






<? 
require "footer.php";
?>




</div><!container>

<?
require "bootstrapbottom.php";
?>